package com.esa.reptils_bio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
